const player = document.getElementById('player');
const obstacle = document.getElementById('obstacle');
const obstacle2 = document.getElementById('obstacle2');
const inicio = document.getElementById('inicio');
const boton = document.getElementById('botonsito');
const score = document.getElementById("score");
let cnt = 0;

function startgame() {
    playerstart('./media/Alien_01.png', arr);
    perder();
    inicializar();
}

function inicializar() {
    inicio.style.zIndex = "-1";
    inicio.style.width = "0";
    inicio.style.height = "0";
    boton.style.fontSize = "0px";
    boton.style.padding = "0px 0px";
}



function saltar() {
    if (player.classList != "animate") {
        player.classList.add("animate");
    }

    setTimeout(function () {
        player.classList.remove("animate");
        cnt++;
        score.setAttribute("value", cnt);
        score.innerHTML = `SCORE: ${score.getAttribute("value")}`;
        if (cnt >= 10 && cnt < 20){
            obstacle.style.animation = "bloque 2.5s infinite linear";
            obstacle2.style.animation = "aceite 2.5s infinite linear";
        }
        else if (cnt >= 20 && cnt < 30){
            obstacle.style.animation = "bloque 2s infinite linear";
            obstacle2.style.animation = "aceite 2s infinite linear";
        }
        else if (cnt >= 30 && cnt < 40){
            obstacle.style.animation = "bloque 1.5s infinite linear";
            obstacle2.style.animation = "aceite 1.5s infinite linear";
        }
        else if (cnt >= 40 && cnt < 50){
            obstacle.style.animation = "bloque 1s infinite linear";
            obstacle2.style.animation = "aceite 1s infinite linear";
        }
        else if (cnt >= 50 && cnt < 100){
            obstacle.style.animation = "bloque 0.7s infinite linear";
            obstacle2.style.animation = "aceite 0.7s infinite linear";
        }
        else if (cnt >= 100 && cnt < 100000){
            obstacle.style.animation = "bloque 0.5s infinite linear";
            obstacle2.style.animation = "aceite 0.5s infinite linear";
        }
    }, 500);
}

window.addEventListener("keypress", event => {
    if (event.key === " " || event.code == "Space") {
        saltar();
    }
});

function perder() {
    var lose = setInterval(function () {
        var playerTop = parseInt(window.getComputedStyle(player).getPropertyValue("top"));
        var blockLeft = parseInt(window.getComputedStyle(obstacle).getPropertyValue("left"));
        var oilspill = parseInt(window.getComputedStyle(obstacle2).getPropertyValue("left"));
        if ((blockLeft < 120 && blockLeft > 50 && playerTop >= 140) || (oilspill < 120 && oilspill > 60 && playerTop >= 120)) {
            obstacle.style.animation = "none";
            obstacle.style.display = "none";
            obstacle2.style.animation = "none";
            obstacle2.style.display = "none";
            alert("SCORE:" + cnt);
            cnt = 0;
        }
    }, 10);
}

var arr = [];

arr = [
    "./media/Alien_01.png",
    "./media/Alien_02.png",
    "./media/Alien_03.png",
    "./media/Alien_04.png",
    "./media/Alien_05.png",
    "./media/Alien_06.png",
    "./media/Alien_07.png",
    "./media/Alien_08.png"
];


var i = 0;


function playerstart() {
    document.getElementById("playerrun").src = arr[i];
    i++;
    if (i == arr.length) {
        i = 0;
    }
    setTimeout(function () { playerstart(); }, 100);
}